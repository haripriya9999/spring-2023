Name:Haripriya Madiraju
B no: B00979051
i used c++ programming language to implement project 3 (a) and (b)
the commands used to run 

(a) g++ -o madiraju_haripriya_pa3_lcs.cpp
$ ./madiraju_haripriya_pa3_lcs <string1> <string2>

(b) ./madiraju_haripriya_pa3_floyd