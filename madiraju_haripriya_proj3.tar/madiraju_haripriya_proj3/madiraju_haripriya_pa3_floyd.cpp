#include <iostream>
#include <vector>
#include <cstdlib>
#include <vector>
#include <climits>
#include <ctime>

using namespace std;

const int MAX_N = 10;
const int MIN_N = 5;

int main()
{
    srand(time(NULL));

    // Generating values randomly  for n 
    int n = rand() % (MAX_N - MIN_N + 1) + MIN_N;
    cout << "Selected n = " << n << endl;

    // Generate the adjacency matrix A
    vector<vector<int> > A(n, vector<int>(n, 0));
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            int weight = rand() % 10 + 1;
            A[i][j] = weight;
            A[j][i] = weight;
        }
    }

    // Display  adjacency matrix A
    cout << "Adjacency matrix:" << endl;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cout << A[i][j] << " ";
        }
        cout << endl;
    }

    // Find all pairs  of shortest paths using Floyd's algorithm
    vector<vector<int> > D(n, vector<int>(n, INT_MAX));
    for (int i = 0; i < n; i++) {
        D[i][i] = 0;
        for (int j = i + 1; j < n; j++) {
            if (A[i][j] != 0) {
                D[i][j] = A[i][j];
                D[j][i] = A[i][j];
            }
        }
    }
    for (int k = 0; k < n; k++) {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (D[i][k] != INT_MAX && D[k][j] != INT_MAX) {
                    D[i][j] = min(D[i][j], D[i][k] + D[k][j]);
                }
            }
        }
    }

    // Display the Floyd's shortest path matrix
    cout << "Floyd's shortest path matrix:" << endl;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (D[i][j] == INT_MAX) {
                cout << "inf ";
            } else {
                cout << D[i][j] << " ";
            }
        }
        cout << endl;
    }

    // Display all pairs shortest paths and their lengths
    cout << "All pairs shortest paths:" << endl;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cout << "Shortest path from " << i << " to " << j << ": ";
            if (D[i][j] == INT_MAX) {
                cout << "No path" << endl;
            } else {
                cout << D[i][j] << endl;
            }
        }
    }

    
    return 0;
}
